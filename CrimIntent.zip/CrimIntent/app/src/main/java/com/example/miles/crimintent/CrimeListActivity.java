package com.example.miles.crimintent;
import android.support.v4.app.Fragment;

/**
 * Created by miles on 4/20/2018.
 */

public class CrimeListActivity extends SingleFragmentActivity {

    @Override
    protected Fragment createFragment() {
        return new CrimeListFragment();
    }
}

